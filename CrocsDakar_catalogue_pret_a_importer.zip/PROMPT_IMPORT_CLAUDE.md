# INSTRUCTION À DONNER À CLAUDE CODE

J'ai préparé le catalogue initial de CrocsDakar / Diaby Store dans le dossier `crocsdakar_catalogue`.

Avant toute importation, inspecte :
- `products.json`
- `products.csv`
- `store-config.json`
- `README.md`
- le dossier `products/`

OBJECTIF :
Importer proprement ce catalogue initial dans la base PostgreSQL/Prisma de l'application CROCSDAKAR, puis envoyer les images vers le stockage d'images configuré (Vercel Blob si c'est celui prévu).

IMPORTANT :
- Ne modifie jamais AURA.
- Ne hardcode pas les produits dans les composants React.
- Utilise la base de données et le système d'administration déjà construits.
- Les futurs produits doivent pouvoir être ajoutés par le vendeur depuis l'admin sans modifier le code.
- Les pointures doivent être des données modifiables par produit.
- Les prix et disponibilités doivent être modifiables.
- Les produits sans prix confirmé ne doivent pas recevoir un prix inventé.
- Vérifie les regroupements d'images avant importation.
- Pour BAPE et Saturday, les variantes/couleurs sont déduites visuellement : garde cette information révisable dans l'admin.
- Pour les produits avec une seule paire restante dans une pointure, respecte la disponibilité actuelle sans inventer d'autres quantités.

Après import :
1. vérifie que chaque produit apparaît correctement ;
2. vérifie la galerie d'images ;
3. vérifie les pointures ;
4. vérifie les prix ;
5. vérifie la recherche ;
6. vérifie l'ajout au panier ;
7. vérifie que le vendeur peut modifier une pointure et un prix depuis l'admin ;
8. vérifie qu'un nouveau produit peut être ajouté depuis l'admin ;
9. lance un build et corrige les erreurs.

Ne publie pas encore les produits dont les informations sont explicitement marquées `a_confirmer` comme si leur prix était confirmé.

Le dossier contient les fichiers et photos réels à utiliser pour l'import.
