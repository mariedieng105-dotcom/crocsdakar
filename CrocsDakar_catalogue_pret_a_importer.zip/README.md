# Catalogue initial CrocsDakar / Diaby Store

Ce dossier contient le catalogue initial extrait de la conversation WhatsApp exportée par le client.

## Contenu
- `products.json` : données structurées prêtes à importer dans la base PostgreSQL/Prisma.
- `products.csv` : version lisible/tableur.
- `store-config.json` : informations publiques de la boutique.
- `products/<id>/` : photos regroupées par produit.

## Règles importantes
1. Ne pas inventer les prix manquants.
2. Les produits dont `price_status` = `a_confirmer` doivent être affichés comme "Prix à confirmer" ou rester masqués jusqu'à validation du vendeur.
3. Les pointures absentes de `sizes` sont considérées indisponibles.
4. Pour Moana Maui, le vendeur a indiqué qu'il reste actuellement une seule paire en 38-39.
5. Pour Moana Classic, le vendeur a indiqué qu'il reste actuellement une seule paire en 41-42.
6. Pour BAPE, six groupes de photos montrent six variantes/couleurs distinctes du même modèle. Les couleurs ont été déduites visuellement des photos et doivent être vérifiées par le vendeur si nécessaire.
7. Pour Saturday Enamel Buckle Sandal, quatre groupes de photos montrent quatre variantes/couleurs distinctes; les couleurs ont été déduites visuellement.
8. Les quantités exactes ne sont pas connues pour la majorité des produits : ne pas inventer de stock numérique.
9. Le vendeur doit pouvoir modifier à tout moment prix, nom, modèle, photos, pointures et disponibilité depuis l'administration.
10. `Pins Crocs` est un accessoire à 350 FCFA l'unité et n'a pas de pointures.

## À intégrer dans CrocsDakar
Importer les produits dans la base de données existante de l'application. Copier les images vers le stockage d'images (Vercel Blob ou autre stockage configuré) et associer leurs URLs aux bons produits.

Ne pas hardcoder ces produits dans les pages React/Next.js.
